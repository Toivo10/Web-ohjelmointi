require('dotenv').config()
const express = require('express')
const morgan = require('morgan')
const cors = require('cors')
const app = express()
const Person = require('./models/person')


app.use(cors())
app.use(express.json())
app.use(morgan('tiny'))
app.use(express.static('dist'))


app.get('/api/persons',(request, response) => {
  Person.find({}).then(persons => {
      response.json(persons)
  })
})

app.post('/api/persons',(request, response) => {
    const body = request.body
    console.log('Adding new person', body.name, body.number)

    if((!body.name || !body.number)){
        console.log('POST failed: name or number is missing!')
        return response.status(400).json({
            error: 'Name or number is missing!'
        })
      }
    const person = new Person({
        name: body.name,
        number: body.number,
    })
    person.save().then(savedPerson => {
        response.json(savedPerson)
    })
})

const PORT = process.env.PORT
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
});